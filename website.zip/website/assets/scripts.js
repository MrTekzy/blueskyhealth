var scrolled = false

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 70 || document.documentElement.scrollTop > 70) {
    document.getElementById("top-nav").style.opacity = "0.84";
	console.log("set: scrolled=true");
  } 
  else {
    document.getElementById("top-nav").style.opacity = "1";
    console.log("set: scrolled=false");
  }
}

function countDownRedir() {
	console.log("loaded: countrd");
    setTimeout(() => {document.getElementById("countrd").innerHTML = "in 4 seconds..."; console.log("countrd: 3")}, 1200);
    setTimeout(() => {document.getElementById("countrd").innerHTML = "in 3 seconds..."; console.log("countrd: 2")}, 2400);
    setTimeout(() => {document.getElementById("countrd").innerHTML = "in 2 seconds..."; console.log("countrd: 1")}, 3600);
    setTimeout(() => {document.getElementById("countrd").innerHTML = "in 1 second..."; console.log("countrd: 1")}, 4800);
    setTimeout(() => {document.getElementById("countrd").innerHTML = "now."; console.log("countrd: 0")}, 6000);
}

